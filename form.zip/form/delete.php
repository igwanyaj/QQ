<?php
include('Connect.php');

if (isset($_GET['id'])) {
 $id = $_GET['id'];
 $sql = "DELETE FROM users WHERE id=$id";
 if ($conn->query($sql) === TRUE) {
 //echo "Record deleted successfully";
 header("location:select.php");
 } else {
 echo "Error deleting record: " . $conn->error;
 }
} else {
 echo "Invalid request";
 exit();
}
$conn->close();
?>