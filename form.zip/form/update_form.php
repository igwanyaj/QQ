<?php
include("Connect.php");

if (isset($_GET['id'])) {
 $id = $_GET['id'];
 // Retrieve data for the selected user
 $sql = "SELECT id, username, email FROM users WHERE id=$id";
 $result = $conn->query($sql);
 if ($result->num_rows > 0) {
 $row = $result->fetch_assoc();
 $username = $row['username'];
 $email = $row['email'];
 } else {
 echo "User not found";
 exit();
 }
} else {
 echo "Invalid request";
 exit();
}
// Display form for updating user data
?>
<!DOCTYPE html>
<html>
<head>
 <title>Update User</title>
</head>
<body>
<form action="update_process.php" method="post">
 <input type="hidden" name="id" value="<?php echo $id; ?>">
 Username: <input type="text" name="username" value="<?php echo $username; ?>"><br>
 Email: <input type="text" name="email" value="<?php echo $email; ?>"><br>
 <input type="submit" value="Update">
</form>
</body>
</html>
