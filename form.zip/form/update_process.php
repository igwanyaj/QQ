<?php
include("Connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $id = $_POST["id"];
 $newUsername = $_POST["username"];
 $newEmail = $_POST["email"];
 $sql = "UPDATE users SET username='$newUsername', email='$newEmail' WHERE id=$id";
 if ($conn->query($sql) === TRUE) {
 //echo "Record updated successfully";
 header("location:select.php");
 } else {
 echo "Error updating record: " . $conn->error;
 }
}
$conn->close();
?>
