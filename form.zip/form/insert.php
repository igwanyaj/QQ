<?php
include("Connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $username = $_POST["username"];
 $email = $_POST["email"];
 $sql = "INSERT INTO users (username, email) VALUES ('$username', '$email')";
 if ($conn->query($sql) === TRUE) {
 //echo "New record created successfully";
 header("location:select.php");
 } else {
 echo "Error: " . $sql . "<br>" . $conn->error;
 }
}
$conn->close();
?>
