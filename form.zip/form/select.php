<?php
include("Connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 20px;
    }

    table {
      border-collapse: collapse;
      width: 80%; 
      margin-top: 20px; 
      border-radius: 10px; 
      overflow: hidden; 
    }

    th, td {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }

    th {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #f5f5f5;
    }

    a {
      text-decoration: none;
    }

    .actions {
      display: flex;
      justify-content: space-between;
    }
  </style>
  <title>User Table</title>
</head>
<body>

<?php
$sql = "SELECT id, username, email FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table><tr><th>ID</th><th>Username</th><th>Email</th><th>Update</th><th>Delete</th></tr>";

  while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["id"]."</td><td>".$row["username"]."</td><td>".$row["email"]."</td>";
    echo "<td class='actions'><a href='update_form.php?id=".$row["id"]."'><b>Update</b></a> </td> <td> <a href='delete.php?id=".$row["id"]."'><b>Delete</b></a></td></tr>";
  }

  echo "</table>";
} else {
  echo "0 results";
}

$conn->close();
?>

</body>
</html>

