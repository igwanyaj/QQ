

<ul class="nav justify-content-center " style="background:lightgray">
<li class="nav-item">
          <div class="nav-link"  style="color:white"><b>{{config('app.name')}}</b></div>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="{{route('home')}}">Home</a>
        </li>
        @auth
        <li class="nav-item">
          <a class="nav-link" href="{{ url('/student') }}">Student</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="{{route('logout')}}">Logout</a>
        </li>

        @else
        <li class="nav-item">
          <a class="nav-link" href="{{route('login')}}">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{route('registration')}}">Register</a>
        </li>

        @endauth
</ul>