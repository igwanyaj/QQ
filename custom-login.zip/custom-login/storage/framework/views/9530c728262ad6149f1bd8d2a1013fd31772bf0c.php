

<ul class="nav justify-content-center " style="background:lightgray">
<li class="nav-item">
          <div class="nav-link"  style="color:white"><b><?php echo e(config('app.name')); ?></b></div>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/student')); ?>">Student</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>
        </li>

        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('registration')); ?>">Register</a>
        </li>

        <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\custom-login\resources\views/include/header.blade.php ENDPATH**/ ?>